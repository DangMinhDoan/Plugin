<div class="uxb-iframe ux" ng-app="uxBuilder" ng-controller="uxIframeCtrl">
	<content></content>
</div>
