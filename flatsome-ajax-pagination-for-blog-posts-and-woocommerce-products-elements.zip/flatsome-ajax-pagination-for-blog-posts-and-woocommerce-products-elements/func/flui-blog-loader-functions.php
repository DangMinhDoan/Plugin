<?php

/*
*  fbl_updates
*
*  The main function responsible for returning the one true fbl_updates instance to functions everywhere.
*  Use this function like you would a global variable, except without needing to declare the global.
*
*  Example: <?php $fbl_updates = fbl_updates(); ?>
*
*  @date	9/4/17
*  @since	5.5.12
*
*  @param	void
*  @return	object
*/

use FLUI_PostLoader\Updates;
function fbl_updates() {
    global $fbl_updates;
    if( !isset($fbl_updates) ) {
        $fbl_updates = new Updates();
    }
    return $fbl_updates;
}
/*
*  fbl_register_plugin_update
*
*  Alias of fbl_updates()->add_plugin().
*
*  @type	function
*  @date	12/4/17
*  @since	5.5.10
*
*  @param	array $plugin
*  @return	void
*/

function fbl_register_plugin_update( $plugin  ) {
    fbl_updates()->add_plugin( $plugin );
 }
