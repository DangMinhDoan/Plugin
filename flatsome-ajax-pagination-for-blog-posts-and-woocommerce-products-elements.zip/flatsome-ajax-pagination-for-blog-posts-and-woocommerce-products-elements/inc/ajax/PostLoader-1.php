<?php

namespace FLUI_PostLoader\Ajax;

defined('ABSPATH') || exit;
use WP_Query;
class PostLoader
{

    public function __construct()
    {
        add_action('init',[$this,"remove_readd_shortcode"]);
        add_action('wp_ajax_post_loader', [$this,"post_loader_init"]);
        add_action('wp_ajax_nopriv_post_loader', [$this,"post_loader_init"]);
    }

    public function remove_readd_shortcode()
    {
        remove_shortcode("blog_posts");
        add_shortcode("blog_posts",[$this,"flui_change_blog_posts"]);
    }
    public function post_loader_init()
    {
        //do bên js để dạng json nên giá trị trả về dùng phải encode
        $data_attrs = (isset($_POST['data_attrs'])) ? esc_attr($_POST['data_attrs']) : '';
        $current_page = (isset($_POST['current_page'])) ? (int)$_POST['current_page'] : 1;

        $result = $this->flui_change_blog_posts_ajax($data_attrs, $current_page);
        wp_send_json_success($result);

        die();//bắt buộc phải có khi kết thúc
    }

    public function flui_change_blog_posts($atts, $content = null, $tag)
    {

        extract(shortcode_atts(array(
            "_id" => 'row-' . rand(),
            'style' => '',
            'class' => '',
            'visibility' => '',

            // Layout
            "columns" => '4',
            "columns__sm" => '1',
            "columns__md" => '',
            'col_spacing' => '',
            "type" => 'slider', // slider, row, masonery, grid
            'width' => '',
            'grid' => '1',
            'grid_height' => '600px',
            'grid_height__md' => '500px',
            'grid_height__sm' => '400px',
            'slider_nav_style' => 'reveal',
            'slider_nav_position' => '',
            'slider_nav_color' => '',
            'slider_bullets' => 'false',
            'slider_arrows' => 'true',
            'auto_slide' => 'false',
            'infinitive' => 'true',
            'depth' => '',
            'depth_hover' => '',

            // posts
            'posts' => '8',
            'ids' => false, // Custom IDs
            'cat' => '',
            'category' => '', // Added for Flatsome v2 fallback
            'excerpt' => 'visible',
            'excerpt_length' => 15,
            'offset' => '',

            // Read more
            'readmore' => '',
            'readmore_color' => '',
            'readmore_style' => 'outline',
            'readmore_size' => 'small',

            // div meta
            'post_icon' => 'true',
            'comments' => 'true',
            'show_date' => 'badge', // badge, text
            'badge_style' => '',
            'show_category' => 'false',

            //Title
            'title_size' => 'large',
            'title_style' => '',

            // Box styles
            'animate' => '',
            'text_pos' => 'bottom',
            'text_padding' => '',
            'text_bg' => '',
            'text_size' => '',
            'text_color' => '',
            'text_hover' => '',
            'text_align' => 'center',
            'image_size' => 'medium',
            'image_width' => '',
            'image_radius' => '',
            'image_height' => '56%',
            'image_hover' => '',
            'image_hover_alt' => '',
            'image_overlay' => '',
            'image_depth' => '',
            'image_depth_hover' => '',

        ), $atts));
        $data_attr = shortcode_atts(array(
            "_id" => 'row-' . rand(),
            'style' => '',
            'class' => '',
            'visibility' => '',

            // Layout
            "columns" => '4',
            "columns__sm" => '1',
            "columns__md" => '',
            'col_spacing' => '',
            "type" => 'slider', // slider, row, masonery, grid
            'width' => '',
            'grid' => '1',
            'grid_height' => '600px',
            'grid_height__md' => '500px',
            'grid_height__sm' => '400px',
            'slider_nav_style' => 'reveal',
            'slider_nav_position' => '',
            'slider_nav_color' => '',
            'slider_bullets' => 'false',
            'slider_arrows' => 'true',
            'auto_slide' => 'false',
            'infinitive' => 'true',
            'depth' => '',
            'depth_hover' => '',

            // posts
            'posts' => '8',
            'ids' => false, // Custom IDs
            'cat' => '',
            'category' => '', // Added for Flatsome v2 fallback
            'excerpt' => 'visible',
            'excerpt_length' => 15,
            'offset' => '',

            // Read more
            'readmore' => '',
            'readmore_color' => '',
            'readmore_style' => 'outline',
            'readmore_size' => 'small',

            // div meta
            'post_icon' => 'true',
            'comments' => 'true',
            'show_date' => 'badge', // badge, text
            'badge_style' => '',
            'show_category' => 'false',

            //Title
            'title_size' => 'large',
            'title_style' => '',

            // Box styles
            'animate' => '',
            'text_pos' => 'bottom',
            'text_padding' => '',
            'text_bg' => '',
            'text_size' => '',
            'text_color' => '',
            'text_hover' => '',
            'text_align' => 'center',
            'image_size' => 'medium',
            'image_width' => '',
            'image_radius' => '',
            'image_height' => '56%',
            'image_hover' => '',
            'image_hover_alt' => '',
            'image_overlay' => '',
            'image_depth' => '',
            'image_depth_hover' => '',

        ), $atts);
        // Stop if visibility is hidden
        if ($visibility == 'hidden') return;

        ob_start();

        $classes_box = array();
        $classes_image = array();
        $classes_text = array();

        // Fix overlay color
        if ($style == 'text-overlay') {
            $image_hover = 'zoom';
        }
        $style = str_replace('text-', '', $style);

        // Fix grids
        if ($type == 'grid') {
            if (!$text_pos) $text_pos = 'center';
            $columns = 0;
            $current_grid = 0;
            $grid = flatsome_get_grid($grid);
            $grid_total = count($grid);
            flatsome_get_grid_height($grid_height, $_id);
        }

        // Fix overlay
        if ($style == 'overlay' && !$image_overlay) $image_overlay = 'rgba(0,0,0,.25)';

        // Set box style
        if ($style) $classes_box[] = 'box-' . $style;
        if ($style == 'overlay') $classes_box[] = 'dark';
        if ($style == 'shade') $classes_box[] = 'dark';
        if ($style == 'badge') $classes_box[] = 'hover-dark';
        if ($text_pos) $classes_box[] = 'box-text-' . $text_pos;

        if ($image_hover) $classes_image[] = 'image-' . $image_hover;
        if ($image_hover_alt) $classes_image[] = 'image-' . $image_hover_alt;
        if ($image_height) $classes_image[] = 'image-cover';

        // Text classes
        if ($text_hover) $classes_text[] = 'show-on-hover hover-' . $text_hover;
        if ($text_align) $classes_text[] = 'text-' . $text_align;
        if ($text_size) $classes_text[] = 'is-' . $text_size;
        if ($text_color == 'dark') $classes_text[] = 'dark';

        $css_args_img = array(
            array('attribute' => 'border-radius', 'value' => $image_radius, 'unit' => '%'),
            array('attribute' => 'width', 'value' => $image_width, 'unit' => '%'),
        );

        $css_image_height = array(
            array('attribute' => 'padding-top', 'value' => $image_height),
        );

        $css_args = array(
            array('attribute' => 'background-color', 'value' => $text_bg),
            array('attribute' => 'padding', 'value' => $text_padding),
        );

        // Add Animations
        if ($animate) {
            $animate = 'data-animate="' . $animate . '"';
        }

        $classes_text = implode(' ', $classes_text);
        $classes_image = implode(' ', $classes_image);
        $classes_box = implode(' ', $classes_box);

        // Repeater styles
        $repeater['id'] = $_id;
        $repeater['tag'] = $tag;
        $repeater['type'] = $type;
        $repeater['class'] = $class;
        $repeater['visibility'] = $visibility;
        $repeater['style'] = $style;
        $repeater['slider_style'] = $slider_nav_style;
        $repeater['slider_nav_position'] = $slider_nav_position;
        $repeater['slider_nav_color'] = $slider_nav_color;
        $repeater['slider_bullets'] = $slider_bullets;
        $repeater['auto_slide'] = $auto_slide;
        $repeater['row_spacing'] = $col_spacing;
        $repeater['row_width'] = $width;
        $repeater['columns'] = $columns;
        $repeater['columns__md'] = $columns__md;
        $repeater['columns__sm'] = $columns__sm;
        $repeater['depth'] = $depth;
        $repeater['depth_hover'] = $depth_hover;

        $args = array(
            'post_status' => 'publish',
            'post_type' => 'post',
            'offset' => $offset,
            'cat' => $cat,
            'posts_per_page' => $posts,
            'ignore_sticky_posts' => true
        );

        // Added for Flatsome v2 fallback
        if (get_theme_mod('flatsome_fallback', 0) && $category) {
            $args['category_name'] = $category;
        }

        // If custom ids
        if (!empty($ids)) {
            $ids = explode(',', $ids);
            $ids = array_map('trim', $ids);

            $args = array(
                'post__in' => $ids,
                'post_type' => array(
                    'post',
                    'featured_item', // Include for its tag archive listing.
                ),
                'numberposts' => -1,
                'orderby' => 'post__in',
                'posts_per_page' => 9999,
                'ignore_sticky_posts' => true,
            );
        }

        $recentPosts = new WP_Query($args);
// Get repeater HTML.
        $this->flui_change_get_flatsome_repeater_start($repeater, $data_attr);

        while ($recentPosts->have_posts()) : $recentPosts->the_post();

            $col_class = array('post-item');

            if (get_post_format() == 'video') $col_class[] = 'has-post-icon';

            if ($type == 'grid') {
                if ($grid_total > $current_grid) $current_grid++;
                $current = $current_grid - 1;

                $col_class[] = 'grid-col';
                if ($grid[$current]['height']) $col_class[] = 'grid-col-' . $grid[$current]['height'];

                if ($grid[$current]['span']) $col_class[] = 'large-' . $grid[$current]['span'];
                if ($grid[$current]['md']) $col_class[] = 'medium-' . $grid[$current]['md'];

                // Set image size
                if ($grid[$current]['size']) $image_size = $grid[$current]['size'];

                // Hide excerpt for small sizes
                if ($grid[$current]['size'] == 'thumbnail') $excerpt = 'false';
            }

            ?>
            <div class="col <?php echo implode(' ', $col_class); ?>" <?php echo $animate; ?>>
                <div class="col-inner">
                    <a href="<?php the_permalink() ?>" class="plain">
                        <div class="box <?php echo $classes_box; ?> box-blog-post has-hover">
                            <?php if (has_post_thumbnail()) { ?>
                                <div class="box-image" <?php echo get_shortcode_inline_css($css_args_img); ?>>
                                    <div class="<?php echo $classes_image; ?>" <?php echo get_shortcode_inline_css($css_image_height); ?>>
                                        <?php the_post_thumbnail($image_size); ?>
                                        <?php if ($image_overlay) { ?>
                                        <div class="overlay"
                                             style="background-color: <?php echo $image_overlay; ?>"></div><?php } ?>
                                        <?php if ($style == 'shade') { ?>
                                            <div class="shade"></div><?php } ?>
                                    </div>
                                    <?php if ($post_icon && get_post_format()) { ?>
                                        <div class="absolute no-click x50 y50 md-x50 md-y50 lg-x50 lg-y50">
                                            <div class="overlay-icon">
                                                <i class="icon-play"></i>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div><!-- .box-image -->
                            <?php } ?>
                            <div class="box-text <?php echo $classes_text; ?>" <?php echo get_shortcode_inline_css($css_args); ?>>
                                <div class="box-text-inner blog-post-inner">

                                    <?php do_action('flatsome_blog_post_before'); ?>

                                    <?php if ($show_category !== 'false') { ?>
                                        <p class="cat-label <?php if ($show_category == 'label') echo 'tag-label'; ?> is-xxsmall op-7 uppercase">
                                            <?php
                                            foreach ((get_the_category()) as $cat) {
                                                echo $cat->cat_name . ' ';
                                            }
                                            ?>
                                        </p>
                                    <?php } ?>
                                    <h5 class="post-title is-<?php echo $title_size; ?> <?php echo $title_style; ?>"><?php the_title(); ?></h5>
                                    <?php if ((!has_post_thumbnail() && $show_date !== 'false') || $show_date == 'text') { ?>
                                        <div class="post-meta is-small op-8"><?php echo get_the_date(); ?></div><?php } ?>
                                    <div class="is-divider"></div>
                                    <?php if ($excerpt !== 'false') { ?>
                                        <p class="from_the_blog_excerpt <?php if ($excerpt !== 'visible') {
                                            echo 'show-on-hover hover-' . $excerpt;
                                        } ?>"><?php
                                            $the_excerpt = get_the_excerpt();
                                            $excerpt_more = apply_filters('excerpt_more', ' [...]');
                                            echo flatsome_string_limit_words($the_excerpt, $excerpt_length) . $excerpt_more;
                                            ?>
                                        </p>
                                    <?php } ?>
                                    <?php if ($comments == 'true' && comments_open() && '0' != get_comments_number()) { ?>
                                        <p class="from_the_blog_comments uppercase is-xsmall">
                                            <?php
                                            $comments_number = get_comments_number(get_the_ID());
                                            /* translators: %s: comment count */
                                            printf(_n('%s Comment', '%s Comments', $comments_number, 'flatsome'),
                                                number_format_i18n($comments_number))
                                            ?>
                                        </p>
                                    <?php } ?>

                                    <?php if ($readmore) { ?>
                                        <button href="<?php echo get_the_permalink(); ?>"
                                                class="button <?php echo $readmore_color; ?> is-<?php echo $readmore_style; ?> is-<?php echo $readmore_size; ?> mb-0">
                                            <?php echo $readmore; ?>
                                        </button>
                                    <?php } ?>

                                    <?php do_action('flatsome_blog_post_after'); ?>

                                </div><!-- .box-text-inner -->
                            </div><!-- .box-text -->
                            <?php if (has_post_thumbnail() && ($show_date == 'badge' || $show_date == 'true')) { ?>
                                <?php if (!$badge_style) $badge_style = get_theme_mod('blog_badge_style', 'outline'); ?>
                                <div class="badge absolute top post-date badge-<?php echo $badge_style; ?>">
                                    <div class="badge-inner">
                                        <span class="post-date-day"><?php echo get_the_time('d', get_the_ID()); ?></span><br>
                                        <span class="post-date-month is-xsmall"><?php echo get_the_time('M', get_the_ID()); ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                        </div><!-- .box -->
                    </a><!-- .link -->
                </div><!-- .col-inner -->
            </div><!-- .col -->
        <?php endwhile;
        wp_reset_query();

// Get repeater end.
        if ($type == "row" && $class == "post_loader") $this->add_flui_flatsome_posts_pagination($recentPosts);
        get_flatsome_repeater_end($atts);
        ?>
        <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public function flui_change_blog_posts_ajax($data_attrs, $current_page)
    {

        $data_attrs = json_decode(html_entity_decode(stripslashes($data_attrs)), true);
        $data_attrs['offset'] = ($current_page - 1) * $data_attrs['posts'];
        $atts = wp_parse_args($data_attrs,
            array(
                "_id" => 'row-' . rand(),
                'style' => '',
                'class' => '',
                'visibility' => '',

                // Layout
                "columns" => '4',
                "columns__sm" => '1',
                "columns__md" => '',
                'col_spacing' => '',
                "type" => 'slider', // slider, row, masonery, grid
                'width' => '',
                'grid' => '1',
                'grid_height' => '600px',
                'grid_height__md' => '500px',
                'grid_height__sm' => '400px',
                'slider_nav_style' => 'reveal',
                'slider_nav_position' => '',
                'slider_nav_color' => '',
                'slider_bullets' => 'false',
                'slider_arrows' => 'true',
                'auto_slide' => 'false',
                'infinitive' => 'true',
                'depth' => '',
                'depth_hover' => '',

                // posts
                'posts' => '8',
                'ids' => false, // Custom IDs
                'cat' => '',
                'category' => '', // Added for Flatsome v2 fallback
                'excerpt' => 'visible',
                'excerpt_length' => 15,
                'offset' => '',

                // Read more
                'readmore' => '',
                'readmore_color' => '',
                'readmore_style' => 'outline',
                'readmore_size' => 'small',

                // div meta
                'post_icon' => 'true',
                'comments' => 'true',
                'show_date' => 'badge', // badge, text
                'badge_style' => '',
                'show_category' => 'false',

                //Title
                'title_size' => 'large',
                'title_style' => '',

                // Box styles
                'animate' => '',
                'text_pos' => 'bottom',
                'text_padding' => '',
                'text_bg' => '',
                'text_size' => '',
                'text_color' => '',
                'text_hover' => '',
                'text_align' => 'center',
                'image_size' => 'medium',
                'image_width' => '',
                'image_radius' => '',
                'image_height' => '56%',
                'image_hover' => '',
                'image_hover_alt' => '',
                'image_overlay' => '',
                'image_depth' => '',
                'image_depth_hover' => ''
            )
        );
        extract($atts);
        // Stop if visibility is hidden
        if ($visibility == 'hidden') return;

        ob_start();
//    echo "<pre>";
//    print_r($data_attrs);
//    echo "</pre>";
        $classes_box = array();
        $classes_image = array();
        $classes_text = array();

        // Fix overlay color
        if ($style == 'text-overlay') {
            $image_hover = 'zoom';
        }
        $style = str_replace('text-', '', $style);

        // Fix grids
        if ($type == 'grid') {
            if (!$text_pos) $text_pos = 'center';
            $columns = 0;
            $current_grid = 0;
            $grid = flatsome_get_grid($grid);
            $grid_total = count($grid);
            flatsome_get_grid_height($grid_height, $_id);
        }

        // Fix overlay
        if ($style == 'overlay' && !$image_overlay) $image_overlay = 'rgba(0,0,0,.25)';

        // Set box style
        if ($style) $classes_box[] = 'box-' . $style;
        if ($style == 'overlay') $classes_box[] = 'dark';
        if ($style == 'shade') $classes_box[] = 'dark';
        if ($style == 'badge') $classes_box[] = 'hover-dark';
        if ($text_pos) $classes_box[] = 'box-text-' . $text_pos;

        if ($image_hover) $classes_image[] = 'image-' . $image_hover;
        if ($image_hover_alt) $classes_image[] = 'image-' . $image_hover_alt;
        if ($image_height) $classes_image[] = 'image-cover';

        // Text classes
        if ($text_hover) $classes_text[] = 'show-on-hover hover-' . $text_hover;
        if ($text_align) $classes_text[] = 'text-' . $text_align;
        if ($text_size) $classes_text[] = 'is-' . $text_size;
        if ($text_color == 'dark') $classes_text[] = 'dark';

        $css_args_img = array(
            array('attribute' => 'border-radius', 'value' => $image_radius, 'unit' => '%'),
            array('attribute' => 'width', 'value' => $image_width, 'unit' => '%'),
        );

        $css_image_height = array(
            array('attribute' => 'padding-top', 'value' => $image_height),
        );

        $css_args = array(
            array('attribute' => 'background-color', 'value' => $text_bg),
            array('attribute' => 'padding', 'value' => $text_padding),
        );

        // Add Animations
        if ($animate) {
            $animate = 'data-animate="' . $animate . '"';
        }

        $classes_text = implode(' ', $classes_text);
        $classes_image = implode(' ', $classes_image);
        $classes_box = implode(' ', $classes_box);

        // Repeater styles
        $repeater['id'] = $_id;
        $repeater['tag'] = $tag;
        $repeater['type'] = $type;
        $repeater['class'] = $class;
        $repeater['visibility'] = $visibility;
        $repeater['style'] = $style;
        $repeater['slider_style'] = $slider_nav_style;
        $repeater['slider_nav_position'] = $slider_nav_position;
        $repeater['slider_nav_color'] = $slider_nav_color;
        $repeater['slider_bullets'] = $slider_bullets;
        $repeater['auto_slide'] = $auto_slide;
        $repeater['row_spacing'] = $col_spacing;
        $repeater['row_width'] = $width;
        $repeater['columns'] = $columns;
        $repeater['columns__md'] = $columns__md;
        $repeater['columns__sm'] = $columns__sm;
        $repeater['depth'] = $depth;
        $repeater['depth_hover'] = $depth_hover;

        $args = array(
            'post_status' => 'publish',
            'post_type' => 'post',
            'offset' => $offset,
            'cat' => $cat,
            'posts_per_page' => $posts,
            'ignore_sticky_posts' => true
        );

        // Added for Flatsome v2 fallback
        if (get_theme_mod('flatsome_fallback', 0) && $category) {
            $args['category_name'] = $category;
        }

        // If custom ids
        if (!empty($ids)) {
            $ids = explode(',', $ids);
            $ids = array_map('trim', $ids);

            $args = array(
                'post__in' => $ids,
                'post_type' => array(
                    'post',
                    'featured_item', // Include for its tag archive listing.
                ),
                'numberposts' => -1,
                'orderby' => 'post__in',
                'posts_per_page' => 9999,
                'ignore_sticky_posts' => true,
            );
        }

        $recentPosts = new WP_Query($args);
// Get repeater HTML.
//echo "<pre>";
//print_r($args);
//echo "</pre>";
        while ($recentPosts->have_posts()) : $recentPosts->the_post();

            $col_class = array('post-item');

            if (get_post_format() == 'video') $col_class[] = 'has-post-icon';

            if ($type == 'grid') {
                if ($grid_total > $current_grid) $current_grid++;
                $current = $current_grid - 1;

                $col_class[] = 'grid-col';
                if ($grid[$current]['height']) $col_class[] = 'grid-col-' . $grid[$current]['height'];

                if ($grid[$current]['span']) $col_class[] = 'large-' . $grid[$current]['span'];
                if ($grid[$current]['md']) $col_class[] = 'medium-' . $grid[$current]['md'];

                // Set image size
                if ($grid[$current]['size']) $image_size = $grid[$current]['size'];

                // Hide excerpt for small sizes
                if ($grid[$current]['size'] == 'thumbnail') $excerpt = 'false';
            }

            ?>
            <div class="col <?php echo implode(' ', $col_class); ?>" <?php echo $animate; ?>>
                <div class="col-inner">
                    <a href="<?php the_permalink() ?>" class="plain">
                        <div class="box <?php echo $classes_box; ?> box-blog-post has-hover">
                            <?php if (has_post_thumbnail()) { ?>
                                <div class="box-image" <?php echo get_shortcode_inline_css($css_args_img); ?>>
                                    <div class="<?php echo $classes_image; ?>" <?php echo get_shortcode_inline_css($css_image_height); ?>>
                                        <?php the_post_thumbnail($image_size); ?>
                                        <?php if ($image_overlay) { ?>
                                        <div class="overlay"
                                             style="background-color: <?php echo $image_overlay; ?>"></div><?php } ?>
                                        <?php if ($style == 'shade') { ?>
                                            <div class="shade"></div><?php } ?>
                                    </div>
                                    <?php if ($post_icon && get_post_format()) { ?>
                                        <div class="absolute no-click x50 y50 md-x50 md-y50 lg-x50 lg-y50">
                                            <div class="overlay-icon">
                                                <i class="icon-play"></i>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div><!-- .box-image -->
                            <?php } ?>
                            <div class="box-text <?php echo $classes_text; ?>" <?php echo get_shortcode_inline_css($css_args); ?>>
                                <div class="box-text-inner blog-post-inner">

                                    <?php do_action('flatsome_blog_post_before'); ?>

                                    <?php if ($show_category !== 'false') { ?>
                                        <p class="cat-label <?php if ($show_category == 'label') echo 'tag-label'; ?> is-xxsmall op-7 uppercase">
                                            <?php
                                            foreach ((get_the_category()) as $cat) {
                                                echo $cat->cat_name . ' ';
                                            }
                                            ?>
                                        </p>
                                    <?php } ?>
                                    <h5 class="post-title is-<?php echo $title_size; ?> <?php echo $title_style; ?>"><?php the_title(); ?></h5>
                                    <?php if ((!has_post_thumbnail() && $show_date !== 'false') || $show_date == 'text') { ?>
                                        <div class="post-meta is-small op-8"><?php echo get_the_date(); ?></div><?php } ?>
                                    <div class="is-divider"></div>
                                    <?php if ($excerpt !== 'false') { ?>
                                        <p class="from_the_blog_excerpt <?php if ($excerpt !== 'visible') {
                                            echo 'show-on-hover hover-' . $excerpt;
                                        } ?>"><?php
                                            $the_excerpt = get_the_excerpt();
                                            $excerpt_more = apply_filters('excerpt_more', ' [...]');
                                            echo flatsome_string_limit_words($the_excerpt, $excerpt_length) . $excerpt_more;
                                            ?>
                                        </p>
                                    <?php } ?>
                                    <?php if ($comments == 'true' && comments_open() && '0' != get_comments_number()) { ?>
                                        <p class="from_the_blog_comments uppercase is-xsmall">
                                            <?php
                                            $comments_number = get_comments_number(get_the_ID());
                                            /* translators: %s: comment count */
                                            printf(_n('%s Comment', '%s Comments', $comments_number, 'flatsome'),
                                                number_format_i18n($comments_number))
                                            ?>
                                        </p>
                                    <?php } ?>

                                    <?php if ($readmore) { ?>
                                        <button href="<?php echo get_the_permalink(); ?>"
                                                class="button <?php echo $readmore_color; ?> is-<?php echo $readmore_style; ?> is-<?php echo $readmore_size; ?> mb-0">
                                            <?php echo $readmore; ?>
                                        </button>
                                    <?php } ?>

                                    <?php do_action('flatsome_blog_post_after'); ?>

                                </div><!-- .box-text-inner -->
                            </div><!-- .box-text -->
                            <?php if (has_post_thumbnail() && ($show_date == 'badge' || $show_date == 'true')) { ?>
                                <?php if (!$badge_style) $badge_style = get_theme_mod('blog_badge_style', 'outline'); ?>
                                <div class="badge absolute top post-date badge-<?php echo $badge_style; ?>">
                                    <div class="badge-inner">
                                        <span class="post-date-day"><?php echo get_the_time('d', get_the_ID()); ?></span><br>
                                        <span class="post-date-month is-xsmall"><?php echo get_the_time('M', get_the_ID()); ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                        </div><!-- .box -->
                    </a><!-- .link -->
                </div><!-- .col-inner -->
            </div><!-- .col -->
        <?php endwhile;
        wp_reset_query();
        // Get repeater end.
        if ($type == "row" && $class == "post_loader") $this->add_flui_flatsome_posts_pagination($recentPosts, $current_page);
        ?>
        <?php
        $content = ob_get_contents();
        ob_end_clean();
        return $content;
    }

    public function flui_change_get_flatsome_repeater_start($atts, $atts_data)
    {
        unset($atts_data['_id']);
        $atts = wp_parse_args($atts,
            array(
                'class' => '',
                'visibility' => '',
                'title' => '',
                'style' => '',
                'columns' => '',
                'columns__sm' => '',
                'columns__md' => '',
                'slider_nav_position' => '',
                'slider_bullets' => 'false',
                'slider_nav_color' => '',
                'auto_slide' => 'false',
                'format' => '',
            )
        );

        $row_classes = array();
        $row_classes_full = array();

        if ($atts['class']) {
            $row_classes[] = $atts['class'];
            $row_classes_full[] = $atts['class'];
        }

        if ($atts['visibility']) {
            $row_classes[] = $atts['visibility'];
            $row_classes_full[] = $atts['visibility'];
        }

        if ($atts['type'] == 'slider-full') {
            $atts['columns'] = false;
            $atts['columns__sm'] = false;
            $atts['columns__md'] = false;
        }

        if (empty($atts)) return;

        if (!empty($atts['filter'])) {
            $row_classes[] = 'row-isotope';
        }

        $rtl = 'false';

        if (is_rtl()) {
            $rtl = 'true';
        }

        if (empty($atts['auto_slide'])) $atts['auto_slide'] = 'false';

        // Group slider cells
        $group_cells = '"100%"';

        // Add column classes
        if (!empty($atts['columns']) && $atts['type'] !== 'grid') {
            if ($atts['columns']) $row_classes[] = 'large-columns-' . $atts['columns'];

            if (empty($atts['columns__md']) && $atts['columns'] > 4) {
                $row_classes[] = 'medium-columns-3';
            } else {
                $row_classes[] = 'medium-columns-' . $atts['columns__md'];
            }

            if (empty($atts['columns__sm']) && $atts['columns'] > 2) {
                $row_classes[] = 'small-columns-2';
            } else {
                $row_classes[] = 'small-columns-' . $atts['columns__sm'];
            }
        }

        // Add Row spacing
        if (!empty($atts['row_spacing'])) {
            $row_classes[] = 'row-' . $atts['row_spacing'];
        }

        // Add row width
        if (!empty($atts['row_width'])) {
            if ($atts['row_width'] == 'full-width') $row_classes[] = 'row-full-width';
        }

        // Add Shadows
        if (!empty($atts['depth'])) {
            $row_classes[] = 'has-shadow';
            $row_classes_full[] = 'box-shadow-' . $atts['depth'];
            $row_classes[] = 'row-box-shadow-' . $atts['depth'];
        }
        if (!empty($atts['depth_hover'])) {
            $row_classes[] = 'has-shadow';
            $row_classes_full[] = 'box-shadow-' . $atts['depth_hover'] . '-hover';
            $row_classes[] = 'row-box-shadow-' . $atts['depth_hover'] . '-hover';
        }

        if ($atts['type'] == 'masonry') {
            wp_enqueue_script('flatsome-masonry-js');
            $row_classes[] = 'row-masonry';
        }

        if ($atts['type'] == 'grid') {
            wp_enqueue_script('flatsome-masonry-js');
            $row_classes[] = 'row-grid';
        }

        if ($atts['type'] == 'slider') {
            $row_classes[] = 'slider row-slider';

            if ($atts['slider_style']) $row_classes[] = 'slider-nav-' . $atts['slider_style'];

            if ($atts['slider_nav_position']) $row_classes[] = 'slider-nav-' . $atts['slider_nav_position'];

            if ($atts['slider_nav_color']) $row_classes[] = 'slider-nav-' . $atts['slider_nav_color'];

            // Add slider push class to normal text boxes
            if (!$atts['style'] || $atts['style'] == 'default' || $atts['style'] == 'normal' || $atts['style'] == 'bounce') $row_classes[] = 'slider-nav-push';

            $slider_options = '{"imagesLoaded": true, "groupCells": ' . $group_cells . ', "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": ' . $atts['slider_bullets'] . ', "rightToLeft": ' . $rtl . ', "autoPlay" : ' . $atts['auto_slide'] . '}';

        } else if ($atts['type'] == 'slider-full') {
            $row_classes_full[] = 'slider slider-auto-height row-collapse';

            if ($atts['slider_nav_position']) $row_classes_full[] = 'slider-nav-' . $atts['slider_nav_position'];

            if ($atts['slider_style']) $row_classes_full[] = 'slider-nav-' . $atts['slider_style'];

            $slider_options = '{"imagesLoaded": true, "dragThreshold" : 5, "cellAlign": "left","wrapAround": true,"prevNextButtons": true,"percentPosition": true,"pageDots": ' . $atts['slider_bullets'] . ', "rightToLeft": ' . $rtl . ', "autoPlay" : ' . $atts['auto_slide'] . '}';
        }

        $row_classes_full = array_unique($row_classes_full);
        $row_classes = array_unique($row_classes);

        $row_classes_full = implode(' ', $row_classes_full);
        $row_classes = implode(' ', $row_classes);
        ?>

        <?php if ($atts['title']) { ?>
        <div class="row">
            <div class="large-12 col">
                <h3 class="section-title"><span><?php echo $atts['title']; ?></span></h3>
            </div>
        </div><!-- end .title -->
    <?php } ?>

        <?php if ($atts['type'] == 'slider') { // Slider grid ?>
        <div class="row <?php echo $row_classes; ?>"  data-flickity-options='<?php echo $slider_options; ?>'>

    <?php } else if ($atts['type'] == 'slider-full') { // Full slider ?>
        <div id="<?php echo $atts['id']; ?>" class="<?php echo $row_classes_full; ?>" data-flickity-options='<?php echo $slider_options; ?>'>

    <?php } else if ($atts['type'] == 'masonry') { // Masonry grid ?>
        <div id="<?php echo $atts['id']; ?>" class="row <?php echo $row_classes; ?>" data-packery-options='{"itemSelector": ".col", "gutter": 0, "presentageWidth" : true}'>

    <?php } else if ($atts['type'] == 'grid') { ?>
        <div id="<?php echo $atts['id']; ?>" class="row <?php echo $row_classes; ?>" data-packery-options='{"itemSelector": ".col", "gutter": 0, "presentageWidth" : true}'>

    <?php } else if ($atts['type'] == 'blank') { //Blank type ?>
        <div class="container">

    <?php }

    else if ($atts['type'] == 'row' && strpos($row_classes, 'post_loader') !== false) { //Blank type ?>
        <div class="row <?php echo $row_classes; ?>" data-flui-load='<?php echo json_encode($atts_data) ?>'>
    <?php }

    else { // Normal Rows ?>
    <div class="row <?php echo $row_classes; ?>">
    <?php }
    }

    public function add_flui_flatsome_posts_pagination($recentPosts, $current_page = 1)
    {

        $prev_arrow = is_rtl() ? get_flatsome_icon('icon-angle-right') : get_flatsome_icon('icon-angle-left');
        $next_arrow = is_rtl() ? get_flatsome_icon('icon-angle-left') : get_flatsome_icon('icon-angle-right');

        $wp_query = $recentPosts;
        $total = $wp_query->max_num_pages;

        $big = 999999999; // need an unlikely integer
        if ($total > 1) {

            if (get_option('permalink_structure')) {
                $format = 'page/%#%/';
            } else {
                $format = '&paged=%#%';
            }
            $pages = paginate_links(array(
                'base' => str_replace($big, '%#%', '#' . $big),
                'format' => $format,
                'current' => max(1, $current_page),
                'total' => $total,
                'mid_size' => 3,
                'type' => 'array',
                'prev_text' => $prev_arrow,
                'next_text' => $next_arrow,
            ));

            if (is_array($pages)) {
                $paged = (get_query_var('paged') == 0) ? 1 : get_query_var('paged');
                echo '<div class="text-center"><ul class="page-numbers nav-pagination links text-center">';
                foreach ($pages as $page) {
                    $page = str_replace("page-numbers", "page-number", $page);
                    echo "<li>$page</li>";
                }
                echo '</ul></div>';
            }
        }
    }
}
