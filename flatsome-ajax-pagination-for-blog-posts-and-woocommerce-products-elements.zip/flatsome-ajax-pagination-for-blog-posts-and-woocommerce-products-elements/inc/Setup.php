<?php

namespace FLUI_PostLoader;

use Exception;

defined('ABSPATH') || exit;

class Setup
{

    /**
     * @var int
     */
    const DB_VERSION = 100;

    /**
     * Installation script.
     *
     * @throws
     * @throws Exception
     */
    public static function install()
    {
        self::checkRequirements();
        self::createTables();
        self::setDefaultSettings();

        flush_rewrite_rules();
    }

    /**
     * Deactivation script.
     */
    public static function deactivate()
    {
        // Nothing for now...
    }

    /**
     * Uninstall script.
     */
    public static function uninstall()
    {
        delete_option('qubelyflui_db_version');
    }

    /**
     * Migration script.
     */
    public static function migrate()
    {
        $currentDatabaseVersion = get_option('qubelyflui_db_version');
    }

    /**
     * Checks if all required plugin components are present.
     *
     * @throws Exception
     */
    public static function checkRequirements()
    {
        if (version_compare(phpversion(), '7.0.0', '<=')) {
            throw new Exception('PHP 5.6 or lower detected. License Manager for WooCommerce requires PHP 7.0.0 or greater.');
        }
    }

    /**
     * Create the necessary database tables.
     */
    public static function createTables()
    {
    }

    /**
     * Sets up the default folder structure and creates the default files,
     * if needed.
     *
     * @throws
     */

    /**
     * Set the default plugin options.
     */
    public static function setDefaultSettings()
    {
        update_option('qubelyflui_db_version', self::DB_VERSION);
    }
}
