<?php
/**
 * Main plugin file.
 * PHP Version: 5.6
 *
 * @category WordPress
 * @package  LicenseManagerForWooCommerce
 * @author   Dražen Bebić <drazen.bebic@outlook.com>
 * @license  GNUv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 * @link     https://www.licensemanager.at/
 */

namespace FLUI_PostLoader;

defined('ABSPATH') || exit;

/**
 * FLUI_PostLoader
 *
 * @category WordPress
 * @package  LicenseManagerForWooCommerce
 * @author   Dražen Bebić <drazen.bebic@outlook.com>
 * @license  GNUv3 https://www.gnu.org/licenses/gpl-3.0.en.html
 * @version  Release: <2.2.0>
 * @link     https://www.licensemanager.at/
 */

use FLUI_PostLoader\Abstracts\Singleton;
use FLUI_PostLoader\Ajax\PostLoader;

final class Main extends Singleton
{

    /**
     * Main constructor.
     *
     * @return void
     */
    public function __construct()
    {
        $this->_defineConstants();
        $this->_initHooks();
        $this->_initAjax();
        add_action('init', array($this, 'init'));

    }

    /**
     * Define plugin constants.
     *
     * @return void
     */
    private function _defineConstants()
    {
        if (!defined('ABSPATH_LENGTH')) {
            define('ABSPATH_LENGTH', strlen(ABSPATH));
        }

        define('FLUI_POSTLOADER_ABSPATH',         dirname(FLUI_POSTLOADER_FILE) . '/');
        define('FLUI_POSTLOADER_BASENAME', plugin_basename(FLUI_POSTLOADER_FILE));

        // Directories
        define('FLUI_POSTLOADER_ASSETS_DIR',     FLUI_POSTLOADER_ABSPATH       . 'assets/');
        define('FLUI_POSTLOADER_LOG_DIR',        FLUI_POSTLOADER_ABSPATH       . 'logs/');
        define('FLUI_POSTLOADER_TEMPLATES_DIR',  FLUI_POSTLOADER_ABSPATH       . 'templates/');
        define('FLUI_POSTLOADER_MIGRATIONS_DIR', FLUI_POSTLOADER_ABSPATH       . 'migrations/');
        define('FLUI_POSTLOADER_CSS_DIR',        FLUI_POSTLOADER_ASSETS_DIR    . 'css/');

        // URL's
        define('FLUI_POSTLOADER_ASSETS_URL', FLUI_POSTLOADER_URL . 'assets/');
        define('FLUI_POSTLOADER_ETC_URL',    FLUI_POSTLOADER_ASSETS_URL . 'etc/');
        define('FLUI_POSTLOADER_CSS_URL',    FLUI_POSTLOADER_ASSETS_URL . 'css/');
        define('FLUI_POSTLOADER_JS_URL',     FLUI_POSTLOADER_ASSETS_URL . 'js/');
        define('FLUI_POSTLOADER_IMG_URL',    FLUI_POSTLOADER_ASSETS_URL . 'img/');
    }

    /**
     * Include JS and CSS files.
     *
     * @param string $hook
     *
     * @return void
     */
    public function enqueueScripts($hook)
    {
        wp_register_style("flui-post-loader", FLUI_POSTLOADER_ASSETS_URL . 'css/flui-post-loader.min.css', "flatsome-style", FLUI_POSTLOADER_VERSION);
        wp_enqueue_style("flui-post-loader");
        wp_register_script('flui-post-loader-js', FLUI_POSTLOADER_ASSETS_URL . 'js/flui-post-loader.min.js', array('jquery'), FLUI_POSTLOADER_VERSION, true);
        wp_enqueue_script('flui-post-loader-js');
    }
    /**
     * Include JS and CSS files.
     *
     * @param string $hook
     *
     * @return void
     */
    public function adminEnqueueScripts($hook)
    {

    }

    /**
     * Add additional links to the plugin row meta.
     *
     * @param array  $links Array of already present links
     * @param string $file  File name
     *
     * @return array
     */
    public function pluginRowMeta($links, $file)
    {
        if (strpos($file, 'flui-post-loader.php') !== false ) {
            $newLinks = array(
                'docs' => sprintf(
                    '<a href="%s" target="_blank" style="display: none;">%s</a>',
                    'https://flatlineui.com/flui-post-loader',
                    __('Documentation', 'flui-post-loader')
                ),
                'donate' => sprintf(
                    '<a href="%s" target="_blank" style="display: none;>%s</a>',
                    'https://www.paypal.com/paypalme/hanhcode/10usd',
                    __('Donate', 'flui-post-loader')
                ),
                'fbl_check_for_updates' => sprintf(
                    '<a href="%s" style="display: none;>%s</a>',
                    add_query_arg( array( 'fbl_check_for_updates' => 1, 'fbl_nonce' => wp_create_nonce( 'fbl_check_for_updates' ) ), network_admin_url( 'plugins.php' ) ),
                    __('Check for updates', 'flui-post-loader')
                )
            );

            $links = array_merge($links, $newLinks);
        }

        return $links;
    }

    /**
     * Hook into actions and filters.
     *
     * @return void
     */
    private function _initHooks()
    {
        register_activation_hook(
            FLUI_POSTLOADER_FILE,
            array('\FLUI_PostLoader\\Setup', 'install')
        );
        register_deactivation_hook(
            FLUI_POSTLOADER_FILE,
            array('\FLUI_PostLoader\\Setup', 'deactivate')
        );
        register_uninstall_hook(
            FLUI_POSTLOADER_FILE,
            array('\FLUI_PostLoader\\Setup', 'uninstall')
        );

        add_action('admin_enqueue_scripts', array($this, 'adminEnqueueScripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueueScripts'));
        add_filter('plugin_row_meta', array($this, 'pluginRowMeta'), 10, 2);
        add_action( 'admin_init', [ $this, 'admin_init_actions' ] );
    }
   
    private function _initAjax()
    {
        new PostLoader();
    }
    /**
     * Init FLUI_PostLoader\ when WordPress Initialises.
     *
     * @return void
     */
    public function init()
    {
        new AdminNotice();
    }

    /**
     * Defines all public hooks
     *
     * @return void
     */
    protected function publicHooks()
    {
        add_filter(
            'qubelyflui_license_keys_table_heading',
            function($text) {
                $default = __('Your license key(s)', 'flui-post-loader');

                if (!$text) {
                    return $default;
                }

                return sanitize_text_field($text);
            },
            10,
            1
        );

        add_filter(
            'qubelyflui_license_keys_table_valid_until',
            function($text) {
                $default = __('Valid until', 'flui-post-loader');

                if (!$text) {
                    return $default;
                }

                return sanitize_text_field($text);
            },
            10,
            1
        );
    }

    /**
     * Checks if a plugin is active.
     *
     * @param string $pluginName
     *
     * @return bool
     */
    private function isPluginActive($pluginName)
    {
        return in_array($pluginName, apply_filters('active_plugins', get_option('active_plugins')));
    }
}
