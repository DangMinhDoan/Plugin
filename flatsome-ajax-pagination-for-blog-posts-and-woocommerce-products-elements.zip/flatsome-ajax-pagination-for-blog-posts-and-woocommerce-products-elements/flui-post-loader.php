<?php
/**
 * Plugin Name: Flatsome Ajax Pagination
 * Plugin URI: https://4t-technology.com/
 * Description: Ajax Pagination For Flatsome Products Element and Posts Element by 4T TECHNOLOGY. Simply add class "post_loader" into the Flatsome Blog Posts Element then enjoy it.
 * Version: 1.0.0
 * Author: 4T TECHNOLOGY
 * Author URI: https://4t-technology.com/
 * Requires at least: 4.7
 * Tested up to: 5.4
 * Requires PHP: 5.6
 * WC requires at least: 2.7
 * WC tested up to: 4.0
 */
namespace FLUI_PostLoader;

defined('ABSPATH') || exit;

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/func/flui-post-loader-functions.php';

// Define LMFWCC_PLUGIN_FILE.
if (!defined('FLUI_POSTLOADER_FILE')) {
    define('FLUI_POSTLOADER_FILE', __FILE__);
    define('FLUI_POSTLOADER_VERSION', "1.0.0");
    define('FLUI_POSTLOADER_DIR', __DIR__);
}

// Define LMFWCC_PLUGIN_URL.
if (!defined('FLUI_POSTLOADER_URL')) {
    define('FLUI_POSTLOADER_URL', plugins_url('', __FILE__) . '/');
}

/**
 * Main instance of LicenseManagerForWooCommerce.
 *
 * Returns the main instance of SN to prevent the need to use globals.
 *
 * @return Main
 */
function qubelyflui()
{
    return Main::instance();
}

// Global for backwards compatibility.
$GLOBALS['qubely-flui'] = qubelyflui();
